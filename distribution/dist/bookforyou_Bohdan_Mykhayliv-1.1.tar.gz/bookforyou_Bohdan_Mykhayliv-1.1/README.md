# Book for you you
#### Christina Georgina Rossetti

## Main idea
This small project has a pretty limited functionality, but it`s still
useful to filter books which are interesting for you.
Program allows user to choose type of sort:
- single choice (1 criterion)
- muptiple choice (3 criterions)
and choose a certain subcriterion from each category choosen before.

As a result, user can choose how many books, which fit these parameters, 
he wanted to get.

## Purpose of the program
The main purpose of this programm --
give user chance to find suitable for its interest films, 
by filtering them.

## How to use?
Program start with **main menu (type menu)** where user can choose type of filtering.
After that user choose criterion (**criterions menu**), which will use later.
Next menu is **subcriterions menu** where user choose desirable subcriterion, which these 
desirable books should fit. (User can print '*random*' -- to choose random criterions)
Last menu is **books number menu**. Here, user can choose how many books he wants to get 
after filtering.

## Result (Output)
**The result(output)** is dataframe with desirable number of books (with their parameters).
